package com.example.my_salon.db.entity

data class UserData(
    val id: String? = null,
    val userName: String? = null,
    val phoneNumber: String? = null
)