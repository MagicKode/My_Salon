package com.example.my_salon.view.relogin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.my_salon.R

class ReLoginFragment : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_relogin_by_phone)
    }
}