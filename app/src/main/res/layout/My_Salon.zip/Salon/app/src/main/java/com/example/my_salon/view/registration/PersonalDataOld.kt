package com.example.my_salon.view.registration

data class PersonalDataOld (
    val firstName: String,
    val email: String,
    val phone: String,
    val oldId: Long
)