package com.example.my_salon.db.dto


class OrderDao {
}