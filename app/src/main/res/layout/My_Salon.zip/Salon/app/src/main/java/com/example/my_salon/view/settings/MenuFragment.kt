package com.example.my_salon.view.settings

import android.os.Bundle
import androidx.fragment.app.Fragment

class MenuFragment : Fragment() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
        }
    }
}