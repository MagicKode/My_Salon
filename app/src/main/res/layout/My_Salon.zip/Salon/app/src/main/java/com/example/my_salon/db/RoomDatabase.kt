package com.example.my_salon.db

class RoomDatabase {
}