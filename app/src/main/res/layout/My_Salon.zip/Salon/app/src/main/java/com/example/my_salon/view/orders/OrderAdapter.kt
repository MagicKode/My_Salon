package com.example.my_salon.view.orders

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView

class OrderAdapter: RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    inner class OrderViewHolder(itemView: View): RecyclerView.ViewHolder(itemView) {
    }


    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): OrderAdapter.OrderViewHolder {
        TODO("Not yet implemented")
    }

    override fun onBindViewHolder(holder: OrderAdapter.OrderViewHolder, position: Int) {
        TODO("Not yet implemented")
    }

    override fun getItemCount(): Int {
        TODO("Not yet implemented")
    }
}